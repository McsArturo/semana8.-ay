### Ejercicios semana 8

##  Ejercicio 1

Pedirle al usuario que ingrese un nombre y una edad en un solo input separados por coma, luego agregue estos datos a un diccionario vacío de la forma nombre:edad.

Esto se realizará indefinidamente hasta que el usuario ingrese la cadena "salir". Convierta edad en entero. No haga validación de entrada.

## Ejercicio 2

Crear una función llamada contarCadena(cad) que recibe una cadena de caracteres, esta función retorna un diccionario donde las claves son los caracteres y los valores son cuántas veces se repiten esos caracteres en la cadena.

## Ejercicio 3
Crear una función llamada presentarD(Dic) que recibe un diccionario y lo imprime por pantalla de la forma:


```

Claves	Valores 
Cl1	V1 
Cl2	V2
```

## Ejercicio 4
Se tiene un diccionario donde sus claves son matrículas y los valores son listas de notas.

Pida al usuario una matrícula. Si esta matrícula ya existe en el diccionario pide que ingrese un número y lo agrega a la lista de notas de esa matrícula.

Si la matrícula no existe, pide que ingrese al menos 3 notas. No haga validación de entrada.

## Ejercicio 5

Se tiene el siguiente diccionario d = {202012345:{"nombre": "Enrique","edad":19}} pida al usuario una matrícula e imprima los datos de esa matrícula, si la matrícula no existe pregunta por nombre y edad para registrarlo.
  